package com.pro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.pro.entity.Student;
import com.pro.repo.StudentRepo;

@SpringBootApplication
public class StudentApplication implements CommandLineRunner {

	@Autowired
	private StudentRepo repo;
	public static void main(String[] args) {
		SpringApplication.run(StudentApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
	
		Student s1=new Student("raju","Hyderabad","raju@gmail.com");
		Student s2=new Student("ajay","vizag","ajay@gmail.com");
		Student s3=new Student("mani","kakinada","mani@gmail.com");
		
		repo.save(s1);
		repo.save(s2);
		repo.save(s3);
		
	}

}
